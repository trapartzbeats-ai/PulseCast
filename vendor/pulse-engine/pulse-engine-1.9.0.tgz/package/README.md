# Pulse Core

Standalone Pulse animation and layout runtime. `src/` is the one authoritative source tree.

## Canonical API (1.9)

Teach and ship the instance path first: create one owner with `const pulse = new Pulse()` and reach systems through `pulse.*`. That path gives every created resource the same owner and makes `pulse.dispose()` a complete teardown boundary. Named classes and lowercase factory aliases remain available for compatibility and advanced composition.

```js
import { Pulse } from 'pulse-engine';

const pulse = new Pulse();
const scene = pulse.scene();
const motion = pulse.timelineEngine({ autoplay: false });

scene.add(motion);
motion.add('.card', { x: 80, opacity: [0, 1], duration: 0.7 }).restart();

// Canonical cleanup for the whole owned graph.
pulse.dispose();
```

See [`docs/guides/CANONICAL_API.md`](./docs/guides/CANONICAL_API.md) for the teaching rules, lifecycle contract, compatibility policy, and Headless/JUCE boundary.

## PMask 4

`PulseMaskMaps` now models browser masking as a track-matte pipeline: source, alpha/luma/RGB channel, operation, edge treatment, independent matte transform, output, and target application. Open [`examples/browser/pmask-workbench.html`](./examples/browser/pmask-workbench.html) for the visible bench and read [`docs/blueprints/PMASK_BLUEPRINT.md`](./docs/blueprints/PMASK_BLUEPRINT.md) for the API contract.

For video inside text or shapes, `attachCanvasComposite()` supplies a true transparent output instead of relying on a rectangular video plus blend mode. It measures item and media dimensions, preserves cover/contain fit, caps pixel density, supports final-pixel matte inset, runs on the shared ticker, honors reduced motion, can recover requested autoplay, and reports proof diagnostics.

## What Is Included

- `src/` engine source, adapters, converters, surfaces, masks, particles, layout, timeline, events, grid, camera, site-experience, and magnet systems.
- `examples/browser/pulse-four-demo.html` full 20-section Pulse test bench.
- `dist/pulse-engine.js` (browser/IIFE), `dist/pulse-engine.mjs` (ESM), declarations in `dist/types/`, and the local `animation-engine.js` compatibility bundle.
- Browser/runtime smoke tests under `tests/smoke/`.
- `package.json`, `package-lock.json`, `tsconfig.json`, and `build.cjs`.

## Repository Layout

Only package entry files remain at the repository root. See [`docs/REPOSITORY_MAP.md`](./docs/REPOSITORY_MAP.md) for the complete map.

- `src/` — authoritative browser runtime source.
- `headless/` — portable Clock/Sink runtime, tests, examples, and reports.
- `src/juce/` + `juce/` — portable document layer and native JUCE consumer.
- `tests/smoke/` — browser/runtime regression scripts.
- `examples/browser/` — standalone browser benches and production-pattern examples.
- `tools/creators/` — mask, texture, particle, and blend creator tools.
- `docs/` — blueprints, patterns, audits, guides, history, and archive material.
- `scripts/` — build/support utilities and external integration sync tools.
- `clients/`, `notebooks-shelf/`, `reports/`, and `output/` — consumers and evidence artifacts.

## Test Commands

```powershell
npm.cmd install
npm.cmd test
```

Open `examples/browser/pulse-four-demo.html` through a local server rooted at this repository so `animation-engine.js` loads normally.

## Flagship client: Pain to Purpose

[`clients/pain-to-purpose/`](./clients/pain-to-purpose/) is the first Pulse 1.9 flagship consumer: an original launch experience for Amber Jackson's forthcoming memoir. It exercises the canonical browser owner, a true-canvas PMask title treatment, deterministic Headless replay, PulseJuce conversion, responsive choreography, and reduced-motion composition. Workbench 2.0 reads its client registry and tracks its remaining production launch gates.

## Character-led editorial pattern

The reusable profile-bar, generated-art quality, face-backdrop, and decorative asset-rain rules are documented in [the character profile pattern](./docs/patterns/PULSE_CHARACTER_PROFILE_PATTERN.md). Use that contract when Pulse motion is applied to transparent character art so transitions preserve the complete artwork instead of clipping the pixels.

The companion [artist EPK pattern](./docs/patterns/PULSE_ARTIST_EPK_PATTERN.md) captures the fixed-stage artist narrative, interactive video wall, media-reactive decoration, flip-gallery, generated asset pack, and proof rules learned from the Sincere Carter EPK.

## Artist Experience Choreography (1.9)

Pulse now owns the interaction seam between a story-driven site and its media. `PulseChapterStage` keeps fixed artwork, labels, and counters synchronized with scrolling chapters. `PulseVideoWall` turns an existing semantic button grid into one selectable featured player. `PulseAudioReactive` exposes live or fallback media energy as CSS variables without owning the artist-specific styling.

`site.frameSequence()` turns Remotion or other rendered image frames into a shared-ticker motion asset with play, pause, seek, loop or ping-pong playback, bounded preloading, reduced-motion settling, diagnostics, and authored-source restoration on dispose. Pair it with `site.mediaCoordinator()` so videos and frame assets only run while their scene is active.

`P.camera()` supports X/Y/Z translation, zoom, roll, tilt, and yaw so a single world container can carry authored `translateZ()` layers through a real perspective camera move. Animate the camera through its adapter rather than applying unrelated tilts to every child.

```js
const P = new Pulse();
const site = P.site({ id: 'artist-epk', mode: 'showcase' });

site.chapterStage({
  sections: '[data-pulse-chapter]',
  stageArt: '[data-pulse-stage-art]',
  label: '#stage-label',
  counter: '#stage-counter',
});

site.videoWall({
  items: videos.map((video) => ({
    ...video,
    embedUrl: `https://www.youtube-nocookie.com/embed/${video.id}?rel=0`,
  })),
  buttons: '.video-tile',
  frame: '#video-frame',
  title: '#video-title',
  meta: '#video-meta',
  counter: '#video-counter',
});

const orbit = site.audioReactive({ media: '#artist-audio', target: '#booking-orbit' });
playButton.addEventListener('click', () => {
  orbit.arm(); // call inside the user gesture before media.play()
  artistAudio.play();
});
```

The reactive target receives `--pulse-audio-bass`, `--pulse-audio-level`, `--pulse-audio-beat`, `data-pulse-audio-state`, and `data-pulse-beat`. CSS remains the visual owner, so the same signal can drive an orbit, logo glow, grain, border, or background wash while reduced motion settles those values to zero.

## Creator Control Connections

Pulse now exposes shared control schemas for the particle, mask-map, texture-map, and blend-mode creator surfaces. The schemas connect the existing input IDs to Pulse adapters, so sliders and selectors use the same read/write seam as bags, signals, timelines, and editor automation.

```js
const P = new Pulse();
const particles = P.particles('#particleRoot', { count: 220 });
const connection = P.controls(particles, document, P.controlSchemas.particles);

// Later, when the surface is removed:
connection.dispose();
particles.dispose();
```

Available schemas are `particles`, `maskMaps`, `textureMaps`, `blendModes`, `layout`, `timeline`, `grid`, `camera`, `events`, `split`, `site`, `spacing`, and `structure`. Continuous creator animation uses the shared Pulse ticker through `autoCycle` or `animate`; it does not create a separate animation loop per surface.

## Editor Integration (1.1)

Pulse Core now owns reusable editor integration contracts instead of requiring each editor to maintain private adapters and project conversion code.

```js
const pulseProject = PulseCore.PulseEditor.convertAtlasProject(atlasProject);
const runtime = PulseCore.PulseEditor.create(pulseProject);
const { targetAdapter } = PulseCore.PulseEditor.registerDomAdapter({
  name: 'my-editor-dom',
  test: (element) => element.closest('#editor') !== null,
});

runtime.registerTarget('title:line', titleElement, targetAdapter);
```

## Composable Webpage Layouts

`PulseLayout` includes the twelve common webpage patterns: `single-column`, `two-column`, `grid`, `f-pattern`, `z-pattern`, `split-screen`, `magazine`, `asymmetrical`, `holy-grail`, `masonry`, `hero-landing`, and `full-screen`.

Use `type` for one container, `types` to map an ordered set of layouts onto direct child sections, or `sections` when each nested target needs an explicit preset.

```js
const pageLayout = P.layout('#page', {
  sections: [
    { target: '#hero', type: 'hero-landing' },
    { target: '#features', type: 'z-pattern' },
    { target: '#gallery', type: 'grid', minColumnWidth: 280 },
    { target: '#final-cta', type: 'single-column' },
  ],
  breakpoints: [
    { maxWidth: 700, type: 'single-column', layoutGap: 16 },
  ],
  layoutGap: 24,
});
```

The presets compose on one page and still retain the existing Anime.js record/update/animate layout transitions.

## Runtime Policy and Packaging (1.2)

Each `Pulse` instance owns and disposes only the resources it creates. Motion policy is instance-scoped and flows into tweens, bags, Anime timelines, text splitting, WAAPI, and custom ticker callbacks.

```js
const P = new Pulse({ motion: { reducedMotion: false, speed: 1, frameRate: 60 } });
```

Editor projects are migrated and validated through `PulseCore.PulseEditor.migrateProject()` and `validateProject()` before runtime use. External bundle copying is explicit; run `npm.cmd run sync:sin-epk` only when that integration target should be updated.

## Coordinated Color Motion (1.3)

`P.colorCycle()` choreographs multi-stop palettes across many elements as one playable. It supports ordinary CSS properties and custom properties, deterministic phase staggering, viewport pause/resume, reduced motion, lifecycle callbacks, adapter-driven progress, and restoration of authored inline styles.

```js
const colors = P.colorCycle([
  { target: '.hero-accent', property: '--accent', colors: ['#c7ff00', '#ffd166', '#ff6a00', '#c7ff00'] },
  { target: '.callout', property: 'backgroundColor', colors: ['#ff6a00', '#ffd166', '#c7ff00'] },
], {
  duration: 8,
  stagger: 0.5,
  visibility: 'viewport',
});

// Scrub the whole palette group through the Pulse adapter seam.
P.writeProp(colors, 'progress', 0.5);
```

## Multi-State SVG Morphing (1.4)

`P.morph()` resamples curved SVG paths into compatible geometry, then exposes the result as one lifecycle-safe playable. It supports any number of states, adapter scrubbing, named state jumps, viewport pause/resume, reduced motion, responsive SVG viewBoxes, and authored-path restoration.

```js
const shape = P.morph('#signalPath', [blobPath, burstPath, wavePath], {
  duration: 6,
  samples: 128,
  loop: true,
  alternate: true,
  visibility: 'viewport',
});

shape.setState(1);
P.writeProp(shape, 'progress', 0.75);
```

The original `P.morphPath(path, from, to)` API remains available and now delegates to `PulseMorph`, so existing two-state integrations receive the improved geometry and cleanup behavior.

## Adaptive Layout Morphing (1.5)

`PulseLayout.transitionTo()` moves one stable set of DOM nodes between any of the twelve webpage layout presets. Pulse records the current geometry, applies the destination CSS layout, and lets Anime AutoLayout perform transform-based FLIP motion. Content identity, focus, responsive CSS, and semantic order remain intact.

```js
const gallery = P.layout('#gallery', {
  type: 'magazine',
  states: ['magazine', 'split-screen', 'masonry'],
  layoutGap: 24,
});

gallery.transitionTo('split-screen', { duration: 0.9, ease: 'outExpo' });
gallery.transitionTo('masonry', { duration: 0.9 }, { minColumnWidth: 320 });
```

Use `transitionSections()` when several nested regions need to change composition in one layout transaction. Responsive breakpoint changes now use the same animated path after the initial layout has been established.

## Typography Morphing (1.6)

`P.typeMorph()` turns accessible split text into a named typographic state machine. Each state can coordinate fill, outline, width, vertical scale, skew, rotation, and alternating scatter through one interruptible timeline. The adapter exposes state and progress controls, reduced motion snaps to the destination treatment, and disposal restores the exact authored markup.

```js
const headline = P.typeMorph('#headline', {
  states: [
    { name: 'solid', fill: '#f2f0e8' },
    { name: 'outline', fill: 'transparent', stroke: '#c7ff00', strokeWidth: 2 },
    { name: 'impact', fill: '#c7ff00', scaleX: 1.1, scatterY: 6, rotate: 2 },
  ],
  initialState: 'solid',
});

headline.setState('impact');
P.writeProp(headline, 'stateIndex', 1);
```

Keep each character run under one motion owner. A layout transition can trigger a type state, but it should not animate the same character transforms independently.

## Image Mask Transitions (1.7)

`P.maskTransition()` coordinates browser-native image reveals across one or more stable elements. Wipe, diagonal, radial, and shutter modes use interruptible clip-path motion with stagger, image finish treatment, reduced-motion completion, adapter control, and exact authored-style restoration.

```js
const posters = P.maskTransition('.project-card img', {
  modes: ['wipe', 'diagonal', 'radial'],
  initialMode: 'wipe',
  duration: 880,
  stagger: 120,
});

posters.reveal('diagonal');
P.writeProp(posters, 'modeIndex', 2);
```

Apply the transition to the image itself when its surrounding card already owns layout or hover transforms. This keeps the mask and composition systems independently interruptible.

## Website Experience Adapters (1.8)

`site.previewPlaylist()` turns a static media element and a set of buttons into a selectable, accessible preview player. It keeps title, collection, counter, store link, pressed states, and playback callbacks synchronized without bundling remote preview audio.

```js
const site = P.site({ id: 'artist-site', mode: 'showcase' });
const player = site.previewPlaylist({
  tracks,
  media: '#artistAudio',
  buttons: '.preview-track',
  title: '#previewTitle',
  collection: '#previewCollection',
  storeLink: '#previewStoreLink',
  autoplayOnSelect: true,
});
```

Image particles now support `glint`, `edgePadding`, and `minOpacity`. Together they keep small sprite fields readable, fully contained, and visibly alive under gravity and turbulence.

```js
P.particles('#logoField', {
  count: 220,
  shape: 'image',
  imageUrl: '/brand-mark.png',
  imageMode: 'sprite',
  gravity: 46,
  glint: 0.7,
  minOpacity: 0.5,
  edgeCollision: true,
  edgePadding: 2,
  autoCycle: true,
});
```

The Atlas converter covers lyric, motion, path, image, and audio clips; typed tracks; assets; local word timing; keyframes; and source-effect metadata. `fingerprintProject()` produces a synchronization signature without embedding large media/data URLs. The DOM adapter uses individual transform properties so Pulse motion composes with an element's authored `transform` instead of replacing it.

## Pulse Experience Kit

Client delivery now has a reusable orchestration layer. `site.responsiveDirector()` owns breakpoint and orientation choreography with teardown on mode changes; `site.mediaCoordinator()` prevents competing audio/video playback; `site.rail()` provides accessible selectable media rails; and `site.selectionLink()` binds one selection to any number of visual consumers.

`validatePulseAssetManifest()` separates public and private deliverables while enforcing image alt text and video posters. `auditPulseRelease()` checks overflow, broken images, unlabeled controls, touch-target warnings, and media state. `PulseMotionBudget` makes experimental effects removable without deleting their engines, while `PulseArchive` models eras and relationships without hard-coding client styling.
